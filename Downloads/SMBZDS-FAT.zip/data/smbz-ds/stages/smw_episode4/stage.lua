-- define stage information

return {
	bgcolor = Color.new256(250,226,178),

	bgs={ -- define number of backgrounds
		{ -- bg 1
			filename = "bg.png",
			offset = {0, -64-30},
			parallax = {0.2, 0.5}, -- 1 = default speed
			tile = {true, false}, -- background repeating/tiling
			scale = true
		},
	},

	ground={ -- define ground tiles
		topFrame = { -- the ground you step on. tiles horizontally only
			0, 0, 96, 16
		},
		loopFrame = { -- below the top frame. tiles horizontally & vertically
			0, 16, 96, 16
		},
		offsetY = 3 -- offset in Y pixels
	}
}