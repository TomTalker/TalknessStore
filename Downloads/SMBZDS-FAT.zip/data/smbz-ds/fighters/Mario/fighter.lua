-- define fighter information

local function reel(engine, player) -- a custom callback function for transitioning from anim airhurt to reeling
	if player.vel[2] >= 0 then player.setAnim("reeling") end
end

local fighter = {
	speed = 300, -- player max speed. 1/100th of a pixel. animations can override this speed
	dash = "run", -- dash animation name override (unused yet)

	sheets = {"mario", "mariohammer"}, -- sprite sheet images to load for this character
	sounds = {"jump", "spinjump", "strain", "eeeiiii", "ha", "ko"}, -- custom WAV files to load for this fighter

	attacks = { -- define animation names for the fighter's moves
		--[[ all possible attack keys:
			neutral
			upneutral
			downneutral
			guardneutral
			guardupneutral
			guarddownneutral
			air
			upair
			downair
			guardair
			guardupair
			guarddownair
			
			prefix "z" on any of these for z-trigger attacks, e.g. "zneutral" or "zdownair"
			you do not need to add all of these; only the ones you deem necessary or add them as you go.
			you can add a maximum of 24 attacks.
		]]

		neutral = "jabcombo",
		upneutral = "uppercut",
		downneutral = "hookpunch",
		air = "smackdown",
		upair = "airuppercut",
		downair = "eaglekick",
		zneutral = "hammerhop",
		zupneutral = "superjumppunch",
		zdownneutral = "hammersmash",
		zair = "hammermeteor",
		zupair = "superjumppunch",
		zdownair = "groundpound",
	},

	anims = { -- all animations. this is the meat of the fighter itself
		idle={
			--name = "idle",
			--img = "mario",
			frames = {
				{x=0, y=0, w=19, h=34, delay=9},
				{x=19, y=0, w=19, h=33, delay=9},
				{x=38, y=0, w=20, h=32, ox={0, 1}, delay=9},
				{x=19, y=0, w=19, h=33, delay=9},
			}
		},

		walk={
			--name = "walk",
			frames = {
				{x=58, y=0, w=20, h=32, delay=7},
				{x=78, y=0, w=22, h=31, delay=7},
				{x=58, y=0, w=20, h=32, delay=7},
				{x=100, y=0, w=17, h=32, delay=7},
				{x=117, y=0, w=21, h=32, delay=7},
				{x=138, y=0, w=22, h=31, delay=7},
				{x=117, y=0, w=21, h=32, delay=7},
				{x=100, y=0, w=17, h=32, delay=7},
			}
		},

		run={
			--name = "run",
			frames = {
				{x=189, y=0, w=27, h=29, delay=6},
				{x=216, y=0, w=26, h=29, delay=6},
				{x=242, y=0, w=28, h=29, delay=6},
				{x=270, y=0, w=28, h=29, delay=6},
				{x=0, y=34, w=27, h=29, delay=6},
				{x=27, y=32, w=27, h=28, delay=6},
				{x=54, y=32, w=28, h=27, delay=6},
				{x=82, y=32, w=28, h=28, delay=6},
			}
		},

		skid={
			--name = "skid",
			frames = {
				{x=160, y=0, w=29, h=31, delay=60}
			}
		},

		jump={
			--name = "jump",
			loop=false,
			frames = {
				{x=110, y=32, w=23, h=31, delay=7},
				{x=133, y=31, w=21, h=37, delay=1,
					callback=function(engine, player) -- called when this frame starts
						-- jump
						player.vel[2] = -500
						player.playSnd("jump")
					end
				},
				{x=133, y=31, w=21, h=37, delay=1,
					callback=function(engine, player)
						if player.vel[2] > 0 then player.setAnim("fall") end
					end
				}
			}
		},

		fall={
			--name = "fall",
			frames = {
				{x=154, y=31, w=24, h=32, delay=60}
			}
		},
		
		guard={
			frames = {
				{x=178, y=31, w=21, h=34, delay=1,
					callback=function(engine, player)
						if not player.inputs.guard and player.pos[2] < 0 then player.setAnim("fall") end
					end
				}
			}
		},

		hurt={
			frames = {
				{x=199, y=29, w=29, h=32, delay=10},
				{x=199, y=29, w=29, h=32, delay=1,
					callback=function(engine, player)
						player.setAnim(player.pos[2] < 0 and "airhurt" or "hurtground")
					end
				}
			}
		},

		hurtground={
			frames = {
				{x=228, y=29, w=18, h=31, delay=60}
			}
		},

		airhurt={
			frames = {
				{x=246, y=29, w=17, h=35, delay=4, callback=reel},
				{x=0, y=63, w=22, h=35, delay=4, callback=reel},
				{x=263, y=29, w=17, h=35, delay=4, callback=reel},
				{x=22, y=60, w=22, h=35, delay=4, callback=reel}
			}
		},

		reeling={
			frames = {
				{x=44, y=59, w=26, h=42, delay=1, rotate=200,
					callback=function(engine, player)
						if player.pos[2] >= 0 then player.setAnim("painful_landing")
						elseif player.stun <= 0 then player.setAnim("fall") end
					end
				}
			}
		},

		painful_landing={
			loop = false,
			frames = {
				{x=70, y=60, w=32, h=18, ox={-2, -2}, delay=5},
				{x=70, y=78, w=36, h=16, delay=5},
				{x=106, y=68, w=36, h=16, delay=1,
					callback=function(engine, player)
						if player.pos[2] < 0 then player.setAnim("reeling")
						elseif player.stun <= 15 then player.setAnim("recover") end
					end
				}
			}
		},

		recover={
			loop = false,
			frames = {
				{x=142, y=66, w=30, h=23, delay=3},
				{x=172, y=65, w=26, h=25, delay=3},
				{x=198, y=61, w=21, h=30, delay=3},
				{x=220, y=60, w=22, h=34, delay=6}
			}
		},
		
		jabcombo={
			loop = false,
			combo = {anim="jabcombo2", frame=4},

			frames = {
				{x=242, y=64, w=25, h=33, delay=4},
				{x=267, y=64, w=32, h=34, ox={-4,-4}, delay=3,
					callback=function(engine, player)
						player.playSnd("missLight")
						player.setAttackBox(true, 16, 8, 16, 26, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitWeakA")
							other.knockBack(50, 0, player, guard, true)
							other.giveDamage(1, 15, guard)
						end)
					end
				},
				{x=0, y=98, w=29, h=34, ox={-3,-3}, delay=3},
				{x=29, y=101, w=23, h=33, ox={-1,-1}, delay=6}
			}
		},

		jabcombo2={
			loop = false,
			combo = {anim="jabcombo3", frame=3},

			frames = {
				{x=52, y=101, w=24, h=34, delay=3},
				{x=76, y=94, w=39, h=32, ox={-7,-7}, delay=3,
					callback=function(engine, player)
						player.playSnd("missLight")
						player.setAttackBox(true, 21, 0, 19, 24, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitWeakA")
							other.knockBack(50, 0, player, guard, true)
							other.giveDamage(1, 15, guard)
						end)
					end
				},
				{x=115, y=88, w=36, h=32, ox={-7,-7}, delay=7}
			}
		},

		jabcombo3={
			loop = false,
			combo = {frame=3},

			frames = {
				{x=151, y=89, w=16, h=34, delay=3},
				{x=167, y=91, w=39, h=32, ox={-11, -11}, delay=4,
					callback=function(engine, player)
						player.playSnd("missA")
						player.setAttackBox(true, 17, 12, 22, 14, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(210, -75, player, guard)
							other.giveDamage(2, 15, guard)
						end)
					end
				},
				{x=206, y=94, w=36, h=32, ox={-10, -10}, delay=4},
				{x=242, y=97, w=29, h=34, ox={-6, -6}, delay=4},
				{x=271, y=98, w=24, h=36, delay=3}
			}
		},
		
		uppercut={
			loop = false,
			combo = {frame=4},
			
			frames = {
				{x=0, y=132, w=20, h=34, delay=3},
				{x=20, y=134, w=21, h=35, delay=3},
				{x=41, y=135, w=22, h=32, ox={-1, -1}, oy=-2, delay=9,
					callback=function(engine, player)
						player.playSnd("missLight")
						player.setAttackBox(true, 12, 0, 11, 18, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(50, -500, player, guard, true)
							other.giveDamage(1, 30, guard)
						end)
					end
				},
				{x=20, y=134, w=21, h=35, delay=2},
			}
		},
		
		hookpunch={
			loop = false,
			combo = {frame=5},
			
			frames = {
				{x=126, y=120, w=25, h=29, ox={-1,-1}, delay=8},
				{x=151, y=123, w=31, h=35, ox={9,9}, delay=5,
					callback=function(engine, player)
						player.playSnd("missB")
					end
				},
				{x=182, y=126, w=40, h=33, ox={-3,-3}, delay=5},
				{x=222, y=131, w=39, h=31, ox={-11,-11}, delay=5,
					callback=function(engine, player)
						player.setAttackBox(true, 22, 0, 18, 24, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(-100, -175, player, guard) -- towards you
							other.giveDamage(3, 20, guard)
						end)
					end
				},
				{x=126, y=120, w=25, h=29, ox={-1,-1}, delay=7}, -- combo here
				{x=126, y=120, w=25, h=29, ox={-1,-1}, delay=1}
			}
		},
		
		smackdown={
			loop = false,
			combo = {frame=4},
			
			frames = {
				{x=226, y=198, w=25, h=36, delay=5},
				{x=145, y=195, w=36, h=36, delay=5,
					callback=function(engine, player)
						player.playSnd("missB")
						player.setAttackBox(true, 18, -1, 19, 38, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(100, 250, player, guard)
							other.giveDamage(1.5, 45, guard)
						end)
					end
				},
				{x=61, y=197, w=32, h=26, delay=20},
			}
		},
		
		airuppercut={
			loop = false,
			combo = {frame=5},
			
			frames = {
				{x=154, y=31, w=24, h=32, delay=4},
				{x=0, y=132, w=20, h=34, delay=4},
				{x=63, y=132, w=32, h=38, delay=4,
					callback=function(engine, player)
						player.playSnd("missLight")
						player.setAttackBox(true, 16, 0, 16, 16, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(50, -500, player, guard)
							other.giveDamage(2, 30, guard)
						end)
					end
				},
				{x=95, y=126, w=31, h=37, delay=18}
			}
		},
		
		eaglekick={
			loop=false,
			combo = {frame=4},

			frames = {
				{x=280, y=29, w=16, h=29, delay=5},
				{x=261, y=134, w=29, h=39, delay=5,
					callback=function(engine, player)
						player.playSnd("missC")
						player.setAttackBox(true, 10, 24, 15, 15, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitWeakB")
							other.knockBack(125, 0, player, guard)
							other.giveDamage(1, 25, guard)
							player.setAnim("eaglekick2")
							player.vel[1] = 100 * -player.dir + player.vel[1]
							player.vel[2] = -400
						end)
					end
				},
				{x=261, y=134, w=29, h=39, delay=15}
			}
		},
		
		eaglekick2={
			loop=false,
			combo = {frame=3},
			
			frames = {
				{x=261, y=134, w=29, h=39, delay=10, callback=function(engine, player) player.rot = 0 end},
				{x=280, y=29, w=16, h=29, rotate=400, delay=30, callback=function(engine, player) player.attacking = false end},
			}
		},
		
		groundpound={
			loop=false,
			combo = {frame=3},

			frames = {
				{x=124, y=149, w=22, h=25, rotate=-600, delay=25,
					callback=function(engine, player)
						player.playSnd("spinjump")
						player.vel[2] = -350
					end
				},
				{x=0, y=169, w=30, h=34, delay=600,
					callback=function(engine, player)
						player.setAttackBox(true, 5, 24, 20, 10, false, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(0, 600, player, guard)
							other.giveDamage(2, 30, guard)
							if other.vel[2] < 0 then other.vel[2] = 0 end -- don't get thrown up
						end)
						player.setAnim("groundpound2", false, true)
					end
				}
			}
		},

		groundpound2={
			combo = {frame=2},
			
			frames = {
				{x=0, y=169, w=30, h=34, delay=1,
					callback=function(engine, player)
						player.vel[1] = 0
						player.vel[2] = 650
						if player.pos[2] >= 0 then player.setAnim("groundpound_land") end
					end
				}
			}
		},

		groundpound_land={
			loop=false,
			combo = {frame=3},
			
			frames = {
				{x=30, y=169, w=32, h=31, delay=4,
					callback=function(engine, player)
						player.setAttackBox(true, 5, 22, 22, 9, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitStrongA")
							other.knockBack(125, -400, player, guard)
							other.giveDamage(3, 25, guard)
						end)
					end
				},
				{x=30, y=169, w=32, h=31, delay=12}
			}
		},
		
		superjumppunch={
			loop=false,
			combo = {frame=12},
			
			frames = {
				{x=62, y=170, w=26, h=27, delay=4},
				{x=88, y=164, w=27, h=33, delay=4,
					callback=function(engine, player)
						engine.playSnd("missB")
						if rand(100) >= 70 then player.playSnd("strain") end
						player.setAttackBox(true, 5, 13, 24, 20, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(50, -400, player, guard, true)
							other.giveDamage(0.84, 15, guard)
						end)
					end
				},
				{x=146, y=158, w=38, h=37, delay=4,
					callback=function(engine, player)
						player.vel[1] = 50 * player.dir
						player.vel[2] = -475
						player.setAttackBox(true, 15, 0, 23, 37, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(50, -400, player, guard, true)
							other.giveDamage(0.84, 15, guard)
						end)
					end
				},
				{x=184, y=159, w=26, h=41, delay=5,
					callback=function(engine, player)
						player.setAttackBox(true, 10, -4, 21, 21, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(50, -400, player, guard, true)
							other.giveDamage(0.84, 15, guard)
						end)
					end
				},
				{x=184, y=159, w=26, h=41, delay=5,
					callback=function(engine, player)
						player.setAttackBox(true, 10, -4, 21, 21, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(50, -400, player, guard, true)
							other.giveDamage(0.84, 15, guard)
						end)
					end
				},
				{x=184, y=159, w=26, h=41, delay=6,
					callback=function(engine, player)
						player.setAttackBox(true, 10, -4, 21, 21, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(50, -400, player, guard, true)
							other.giveDamage(0.84, 15, guard)
						end)
					end
				},
				{x=210, y=162, w=22, h=39, delay=6,
					callback=function(engine, player)
						player.setAttackBox(true, 10, -4, 16, 17, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(50, -400, player, guard, true)
							other.giveDamage(0.84, 15, guard)
						end)
					end
				},
				{x=232, y=162, w=17, h=34, delay=5},
				{x=249, y=173, w=21, h=33, delay=5},
				{x=270, y=173, w=24, h=33, delay=4},
			}
		},
		
		hammerhop={
			loop=false,
			combo = {frame=7},
			img = "mariohammer",
			
			frames = {
				{x=0, y=0, w=35, h=34, ox={8,8}, delay=12},
				{x=35, y=0, w=39, h=47, ox={10,10}, delay=12,
					callback=function(engine, player)
						player.vel[1] = 325 * player.dir
						player.vel[2] = -125
					end
				},
				{x=74, y=0, w=40, h=52, ox={-7,-8}, delay=6,
					callback=function(engine, player)
						player.setAttackBox(true, 9, 0, 32, 33, false, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(100, -300, player, guard, true)
							other.giveDamage(3, 33, guard)
						end)
					end
				},
				{x=114, y=0, w=37, h=31, ox={-9,-9}, delay=6,
					callback=function(engine, player)
						-- don't turn attackbox on again if player was already hit (1st argument)
						player.setAttackBox(player.attackbox.on, 15, 0, 22, 31, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(100, -300, player, guard, true)
							other.giveDamage(3, 33, guard)
						end)
					end
				},
				{x=114, y=31, w=38, h=34, ox={-9,-9}, oy=2, delay=6},
				{x=0, y=37, w=38, h=32, ox={-9,-9}, oy=2, delay=8},
			}
		},
		
		hammersmash={
			loop = false,
			combo = {frame=14},
			img = "mariohammer",
			breakthrough = true, -- this is here to tell the AI to react to this

			-- this attack breaks through player guard

			frames = {
				{x=38, y=47, w=24, h=41, ox={3,3}, oy=9, delay=6,
					callback=function(engine, player)
						player.playSnd("strain")
					end
				},
				{x=62, y=52, w=29, h=39, ox={6,5}, oy=7, delay=5},
				{x=91, y=66, w=34, h=34, ox={8,8}, oy=2, delay=5},
				{x=125, y=65, w=38, h=32, ox={10,10}, delay=5},
				{x=151, y=0, w=37, h=32, ox={10,9}, delay=5},
				{x=152, y=32, w=37, h=33, ox={10,10}, delay=5},
				{x=0, y=69, w=35, h=47, ox={7,7}, delay=5,
					callback=function(engine, player)
						player.setAttackBox(true, -1, -1, 21, 28, false, function(engine, player, other, guard)
							engine.playSnd("hitStrongA")
							other.knockBack(175, -300, player)
							other.giveDamage(6, 60)
						end)
					end
				},
				{x=35, y=91, w=41, h=52, ox={-3,-3}, delay=5,
					callback=function(engine, player)
						player.setAttackBox(player.attackbox.on, 0, 0, 41, 24, false, function(engine, player, other, guard)
							engine.playSnd("hitStrongA")
							other.knockBack(175, -300, player)
							other.giveDamage(6, 60)
						end)
					end
				},
				{x=76, y=100, w=40, h=52, ox={-18,-18}, delay=5,
					callback=function(engine, player)
						player.setAttackBox(player.attackbox.on, 0, 0, 40, 48, false, function(engine, player, other, guard)
							engine.playSnd("hitStrongA")
							other.knockBack(175, -300, player)
							other.giveDamage(6, 60)
						end)
					end
				},
				{x=116, y=100, w=42, h=50, ox={-19,-19}, delay=5,
					callback=function(engine, player)
						player.setAttackBox(player.attackbox.on, 18, 0, 24, 46, false, function(engine, player, other, guard)
							engine.playSnd("hitStrongA")
							other.knockBack(175, -300, player)
							other.giveDamage(6, 60)
						end)
					end
				},
				{x=163, y=65, w=42, h=37, ox={-19,-19}, delay=5,
					callback=function(engine, player)
						player.setAttackBox(player.attackbox.on, 21, 0, 21, 36, true, function(engine, player, other, guard)
							engine.playSnd("hitStrongA")
							other.knockBack(175, -300, player)
							other.giveDamage(6, 60)
						end)
					end
				},
				{x=158, y=102, w=39, h=30, ox={-17,-18}, delay=5},
				{x=157, y=132, w=38, h=30, ox={-17,-17}, delay=5}
			}
		},

		hammermeteor={
			loop=false,
			combo = {frame=8},
			img = "mariohammer",
			breakthrough = true, -- this is here to tell the AI to react to this

			-- this attack breaks through player guard

			frames = {
				{x=0, y=122, w=41, h=54, ox={11,11}, delay=4,
					callback=function(engine, player)
						player.rot = 0
						player.playSnd("eeeiiii")
					end
				},
				{x=41, y=152, w=51, h=39, ox={11,11}, rotate=2, delay=4},
				{x=92, y=151, w=56, h=33, ox={14,14}, rotate=5, delay=4},
				{x=192, y=159, w=56, h=33, ox={14,14}, rotate=10, delay=18},
				{x=189, y=0, w=45, h=54, ox={9,9}, rotate=-15, delay=3},
				{x=197, y=101, w=40, h=39, ox={14,14}, scale={2,2}, ox={-5,-5}, oy=9, delay=3,
					callback=function(engine, player)
						engine.playSnd("missB")
						player.playSnd("ha")
						player.setAttackBox(true, 31, 0, 52, 78, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitStrongB")
							other.knockBack(200, 350, player)
							other.giveDamage(4, 60)
						end)
					end
				},
				{x=205, y=54, w=43, h=47, ox={14,14}, ox={7,7}, oy=20, delay=1,
					callback=function(engine, player)
						player.setAnim("hammermeteor2")
					end
				},
			}
		},
		
		hammermeteor2={
			combo = {frame=1},
			img = "mariohammer",

			frames = {
				{x=205, y=54, w=43, h=47, ox={14,14}, ox={7,7}, oy=20, delay=1,
					callback=function(engine, player)
						if player.pos[2] >= 0 then
							player.setAnim("hammermeteor_land")
						end
					end
				},
			}
		},
		
		hammermeteor_land={
			loop=false,
			combo = {frame=7},

			frames = {
				{x=115, y=174, w=27, h=26, delay=10},
				{x=93, y=197, w=26, h=28, ox={-3,-3}, delay=4},
				{x=119, y=200, w=26, h=31, ox={-3,-3}, delay=4},
				{x=35, y=200, w=26, h=32, ox={-3,-3}, delay=4},
				{x=181, y=200, w=25, h=33, ox={-2,-2}, delay=4},
				{x=206, y=201, w=20, h=33, delay=4},
			}
		}
	}
}

local TACTIC_JABS = 0
local TACTIC_JABTHENHOOK = 1
local TACTIC_UPPERCUT = 2
local TACTIC_JUMPPUNCH = 3
local TACTIC_HAMMERHOP = 4
local TACTIC_HAMMERSMASH = 5
local TACTIC_GROUNDPOUND = 6
local MAX_TACTICS = 7

local cpuEnemy, cpuGuard, cpuTactic, cpuTacticState, cpuTacticSwitch, cpuAttackTick, cpuReleaseAttack

function fighter.cpu(engine, player)
	if not cpuEnemy then
		cpuGuard = 0
		cpuTactic = rand(MAX_TACTICS)
		cpuTacticState = 0
		cpuTacticSwitch = 120 + rand(60)
		cpuAttackTick = 8
		for i=1, #engine.players do
			if engine.players[i] ~= player then
				cpuEnemy = engine.players[i]
				break
			end
		end
	end

	local inputs = player.inputs
	local frame = player.anims[player.anim.name]

	--local dist = math.sqrt(math.pow(cpuEnemy.pos[2] - player.pos[2], 2) + math.pow(cpuEnemy.pos[1] - player.pos[1], 2))
	local xdiff = cpuEnemy.pos[1] - player.pos[1]
	local xdist = math.abs(xdiff)
	local xdir = xdiff >= 0 and 1 or -1
	local ydiff = cpuEnemy.pos[2] - player.pos[2]
	local ydist = math.abs(ydiff)
	local ydir = (cpuEnemy.pos[2] > player.pos[2] and 1) or (cpuEnemy.pos[2] < player.pos[2] and -1) or 0

	local avoidPlayer = cpuEnemy.attacking and cpuEnemy.anims[cpuEnemy.anim.name].breakthrough and xdist < 56
	if avoidPlayer and cpuGuard > 10 then
		cpuGuard = rand(10)
	end

	if player.stun > 0 then
		cpuGuard = 15 + rand(60)
		inputs.attack = false

	elseif player.guardStun > 0 then
		cpuGuard = 10 + rand(20)
		inputs.attack = false

	elseif cpuGuard > 0 then
		cpuGuard = cpuGuard-1
		inputs.attack = false

	else
		inputs.dir.x = (avoidPlayer and -xdir) or ((xdist > 16 or player.dir ~= xdir) and xdir) or 0
	end

	cpuTacticSwitch = cpuTacticSwitch-1
	if cpuTacticSwitch <= 0 then
		cpuTactic = rand(MAX_TACTICS)
		cpuTacticState = 0
		cpuTacticSwitch = 60 + rand(30)
	end

	local anim = player.anims[player.anim.name]
	inputs.jump = false
	if cpuTactic == TACTIC_JABS and xdist <= 40 and ydist < 32 then
		inputs.attack = true
		inputs.dir.y = 0
		inputs.trigger = false
		inputs.jump = rand(53) >= 46
		cpuTacticSwitch = cpuTacticSwitch-1

	elseif cpuTactic == TACTIC_JABTHENHOOK and xdist <= 40 and ydist < 32 then
		inputs.attack = true
		inputs.trigger = false
		inputs.dir.y = (player.anim.name == "jabcombo2" and player.anim.frame >= anim.combo.frame) and 1 or 0
		local nextt = player.anim.name == "hookpunch" and rand(50) or 0
		if nextt >= 40 then
			cpuTactic = TACTIC_JUMPPUNCH
			cpuTacticSwitch = 90
		elseif nextt >= 30 then
			cpuTactic = TACTIC_UPPERCUT
			cpuTacticSwitch = 90
		end

	elseif cpuTactic == TACTIC_UPPERCUT or (xdist < 32 and ydist < 32) then
		inputs.dir.y = -1
		inputs.trigger = false
		inputs.attack = true
		if rand(50) >= 40 then
			cpuTactic = rand(MAX_TACTICS)
			cpuTacticSwitch = 90
		end

	elseif cpuTactic == TACTIC_JUMPPUNCH and xdist <= 40 and ydist < 56 then
		inputs.dir.y = -1
		inputs.trigger = true
		inputs.attack = true

	elseif cpuTactic == TACTIC_HAMMERHOP and xdist < 64 and ydist < 48 then
		inputs.dir.y = 0
		inputs.trigger = true
		inputs.attack = true
		inputs.jump = rand(53) >= 46 -- randomly transform into hammer meteor smash

	elseif cpuTactic == TACTIC_HAMMERSMASH and xdist < 48 then
		inputs.dir.y = 1
		inputs.trigger = true
		inputs.attack = true
		cpuTactic = rand(MAX_TACTICS)
		cpuTacticSwitch = 90

	elseif cpuTactic == TACTIC_GROUNDPOUND and xdist < 104 then
		inputs.jump = true
		inputs.trigger = false
		inputs.attack = false
		if ydir > 0 and xdist < 60 then -- we're above
			inputs.dir.y = 1
			inputs.trigger = true
			inputs.attack = true
			if rand(30) >= 20 then
				cpuTactic = rand(MAX_TACTICS)
				cpuTacticSwitch = 90
			end
		end

	else
		inputs.attack = false
		inputs.trigger = false
	end

	if inputs.attack then
		if cpuAttackTick <= 0 then cpuAttackTick = 5
		else
			cpuAttackTick = cpuAttackTick-1
			inputs.attack = false
		end
	else
		cpuAttackTick = 8
	end

	inputs.guard = cpuGuard > 0
end

return fighter
