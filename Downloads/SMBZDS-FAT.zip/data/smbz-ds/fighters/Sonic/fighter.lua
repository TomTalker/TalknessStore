-- define fighter information

local function stopdashing(player) -- a custom callback function for transitioning from anim spindash
	if not player.inputs.attackHold or player.anim.frame >= #player.anims[player.anim.name].frames then
		player.chargePower = player.anim.frame >= 18 and 1 or 0
		player.setAnim(player.anim.frame >= 13 and "spindash_boost" or "spindash_slide1")
	end
end

local fighter = {
	speed = 300, -- player max speed. 1/100th of a pixel. animations can override this speed
	dash = "run", -- dash animation name override (unused yet)

	sheets = {"sonic", "sonicball"}, -- sprite sheet images to load for this character
	sounds = {"jump", "ko", "humm", "chea", "spin", "stopspin", "spring", "ya"}, -- custom WAV files to load for this fighter

	attacks = { -- define animation names for the fighter's moves
		--[[ all possible attack keys:
			neutral
			upneutral
			downneutral
			guardneutral
			guardupneutral
			guarddownneutral
			air
			upair
			downair
			guardair
			guardupair
			guarddownair
			
			prefix "z" on any of these for z-trigger attacks, e.g. "zneutral" or "zdownair"
			you do not need to add all of these; only the ones you deem necessary or add them as you go.
			you can add a maximum of 24 attacks.
		]]

		neutral = "jabcombo",
		upneutral = "flipkick",
		downneutral = "sweepkick",
		zneutral = "spindash",
		zupneutral = "bounce",
		zdownneutral = "flashkick",
		air = "tornadokick",
		upair = "flipkick",
		downair = "downkick",
		zair = "soniceagle",
		zupair = "bounceair",
		zdownair = "divekick"
	},

	anims = { -- all animations. this is the meat of the fighter itself
		idle={
			frames={
				{x=0, y=0, w=23, h=33, delay=7},
				{x=23, y=0, w=23, h=32, ox={-2,-2}, delay=7},
				{x=46, y=0, w=23, h=31, ox={-3,-3}, delay=7},
				{x=23, y=0, w=23, h=32, ox={-2,-2}, delay=7},
				{x=0, y=0, w=23, h=33, delay=7},
				{x=115, y=0, w=23, h=33, delay=7},
				{x=138, y=0, w=23, h=32, delay=7},
				{x=115, y=0, w=23, h=33, delay=7},
			}
		},

		walk={
			frames={
				{x=161, y=0, w=22, h=35, ox={-1,-1}, delay=7},
				{x=183, y=0, w=29, h=31, ox={-1,-1}, delay=7},
				{x=212, y=0, w=21, h=33, ox={-1,-1}, delay=7},
				{x=233, y=0, w=21, h=35, ox={-1,-1}, delay=7},
				{x=254, y=0, w=23, h=34, ox={-1,-1}, delay=7},
				{x=277, y=0, w=28, h=32, delay=7},
				{x=69, y=0, w=22, h=33, ox={-2,-2}, delay=7}
			}
		},

		run={
			frames={
				{x=305, y=0, w=27, h=34, delay=6},
				{x=0, y=33, w=31, h=32, ox={2,2}, delay=6},
				{x=31, y=32, w=38, h=31, ox={5,5}, delay=6},
				{x=69, y=33, w=34, h=31, ox={4,4}, delay=6},
				{x=103, y=33, w=27, h=33, delay=6},
				{x=130, y=34, w=32, h=34, ox={3,3}, delay=6},
				{x=162, y=35, w=38, h=32, ox={5,5}, delay=6},
				{x=200, y=33, w=33, h=32, ox={3,3}, delay=6},
			}
		},

		skid={
			frames={
				{x=233, y=35, w=40, h=29, delay=60}
			}
		},

		jump={
			loop=false,

			frames={
				{x=273, y=34, w=25, h=31, delay=6},
				{x=273, y=34, w=25, h=31, delay=1,
					callback=function(engine, player)
						player.vel[2] = -500
						player.playSnd("jump")
						player.setAnim("jump2")
					end
				},
			}
		},

		jump2={
			frames={
				{x=298, y=34, w=26, h=31, rotate=-400, delay=3,
					callback=function(engine, player)
						if player.vel[2] > 0 then player.setAnim("fall") end
					end
				},
				{x=0, y=65, w=27, h=30, rotate=-400, delay=3,
					callback=function(engine, player)
						if player.vel[2] > 0 then player.setAnim("fall") end
					end
				}
			}
		},

		fall={
			loop=false,

			frames={
				{x=27, y=63, w=35, h=39, delay=1}
			}
		},

		guard={
			frames={
				{x=62, y=64, w=23, h=32, delay=60}
			}
		},

		hurt={
			loop=false,

			frames={
				{x=85, y=66, w=34, h=34, delay=5},
				{x=119, y=68, w=31, h=32, oy=-1, delay=5},
				{x=119, y=68, w=31, h=32, oy=-1, delay=1,
					callback=function(engine, player)
						player.setAnim(player.pos[2] < 0 and "airhurt" or "hurtground")
					end
				},
			}
		},

		hurtground={
			loop=false,
			
			frames={
				{x=150, y=68, w=25, h=32, delay=60}
			}
		},

		airhurt={
			loop=false,

			frames={
				{x=175, y=67, w=19, h=39, delay=1,
					callback=function(engine, player)
						if player.vel[2] >= 0 then player.setAnim("reeling") end
					end
				}
			}
		},

		reeling={
			loop=false,

			frames={
				{x=194, y=66, w=37, h=33, delay=1, rotate=200,
					callback=function(engine, player)
						if player.pos[2] >= 0 then player.setAnim("painful_landing")
						elseif player.stun <= 0 then player.setAnim("fall") end
					end
				}
			}
		},

		painful_landing={
			loop=false,

			frames={
				{x=231, y=64, w=34, h=26, delay=5},
				{x=265, y=65, w=36, h=25, delay=5},
				{x=0, y=97, w=38, h=24, ox={1,1}, delay=5},
				{x=57, y=97, w=35, h=22, ox={2,2}, delay=5,
					callback=function(engine, player)
						if player.pos[2] < 0 then player.setAnim("reeling")
						elseif player.stun <= 30 then player.setAnim("recover") end
					end
				},
			}
		},

		recover={
			loop=false,

			frames={
				{x=295, y=88, w=34, h=28, delay=5},
				{x=271, y=90, w=24, h=34, ox={6,6}, delay=5},
				{x=301, y=65, w=30, h=23, ox={10,10}, delay=5},
				{x=241, y=90, w=30, h=35, ox={3,3}, delay=5},
				{x=92, y=100, w=35, h=26, oy=-8, delay=5},
				{x=216, y=97, w=25, h=34, delay=5}
			}
		},

		jabcombo={
			loop=false,
			combo = {anim="jabcombo2", frame=3},

			frames={
				{x=127, y=100, w=24, h=33, delay=4},
				{x=151, y=106, w=38, h=33, ox={-7,-7}, delay=4,
					callback=function(engine, player)
						player.playSnd("missLight")
						player.setAttackBox(true, 21, 2, 18, 25, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitWeakA")
							other.knockBack(50, 0, player, guard, true)
							other.giveDamage(1, 15, guard)
						end)
					end
				},
				{x=189, y=105, w=21, h=32, ox={-2,-2}, delay=8}
			}
		},

		jabcombo2={
			loop=false,
			combo = {anim="jabcombo3", frame=3},

			frames={
				{x=0, y=121, w=22, h=33, ox={-1,-1}, delay=4},
				{x=22, y=121, w=26, h=33, ox={-4,-4}, delay=4,
					callback=function(engine, player)
						player.playSnd("missLight")
						player.setAttackBox(true, 13, 13, 14, 20, false, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitWeakA")
							other.knockBack(50, 0, player, guard, true)
							other.giveDamage(1, 15, guard)
						end)
					end
				},
				{x=48, y=119, w=39, h=33, ox={-4,-4}, delay=4,
					callback=function(engine, player)
						player.setAttackBox(player.attackbox.on, 13, 10, 27, 23, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitWeakA")
							other.knockBack(50, 0, player, guard, true)
							other.giveDamage(1, 15, guard)
						end)
					end
				},
				{x=87, y=126, w=28, h=32, ox={-4,-4}, delay=8}
			}
		},

		jabcombo3={
			loop=false,
			combo = {frame=6},

			frames={
				{x=302, y=116, w=32, h=34, ox={-6,-6}, delay=4},
				{x=268, y=124, w=34, h=35, ox={-6,-6}, delay=4,
					callback=function(engine, player)
						player.playSnd("missA")
						player.setAttackBox(true, 16, 13, 19, 22, false, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(210, -300, player, guard)
							other.giveDamage(2, 20, guard)
						end)
					end
				},
				{x=235, y=131, w=33, h=30, ox={-6,-6}, oy=-6, delay=4,
					callback=function(engine, player)
						player.setAttackBox(player.attackbox.on, 19, 1, 15, 26, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(210, -300, player, guard)
							other.giveDamage(2, 20, guard)
						end)
					end
				},
				{x=115, y=133, w=34, h=26, ox={-4,-4}, oy=-9, delay=4}
			}
		},

		sweepkick={
			loop=false,
			combo = {frame=9},

			frames={
				{x=149, y=139, w=27, h=31, delay=5,
					callback=function(engine, player)
						player.playSnd("swing")
					end
				},
				{x=176, y=137, w=31, h=35, delay=5},
				{x=0, y=154, w=39, h=32, ox={-3,-3}, delay=5,
					callback=function(engine, player)
						player.setAttackBox(true, 21, 4, 20, 24, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(210, -300, player, guard)
							other.giveDamage(3, 50, guard)
						end)
					end
				},
				{x=39, y=152, w=31, h=37, ox={6,6}, delay=5},
				{x=70, y=158, w=39, h=32, ox={7,7}, delay=5,
					callback=function(engine, player)
						player.setAttackBox(true, -1, 6, 18, 22, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(-210, -300, player, guard)
							other.giveDamage(3, 50, guard)
						end)
					end
				},
				{x=211, y=131, w=21, h=43, ox={-4,-4}, delay=11,
					tick=function(player)
						if player.inputs.jump then
							player.vel[2] = -500
							player.setAnim("sweepkick_jump")
							player.attacking = false
						end
					end
				},
				{x=109, y=159, w=39, h=39, ox={5,5}, delay=5,
					tick=function(player)
						if player.inputs.jump then
							player.vel[2] = -500
							player.setAnim("sweepkick_jump")
							player.attacking = false
						end
					end
				},
				{x=308, y=150, w=26, h=33, ox={-4,-4}, delay=5,
					tick=function(player)
						if player.inputs.jump then
							player.vel[2] = -500
							player.setAnim("sweepkick_jump")
							player.attacking = false
						end
					end
				},
			}
		},

		sweepkick_jump={
			loop=false,
			combo = {frame=10},

			frames={
				{x=288, y=159, w=21, h=45, delay=4, callback=function(engine, player) player.playSnd("airrecover") end},
				{x=259, y=159, w=29, h=41, delay=4},
				{x=237, y=161, w=22, h=39, delay=4},
				{x=148, y=170, w=32, h=34, delay=4},
				{x=180, y=172, w=32, h=26, delay=4},
				{x=0, y=186, w=36, h=26, delay=4},
				{x=36, y=189, w=26, h=37, delay=4},
				{x=309, y=183, w=25, h=40, delay=4},
				{x=62, y=190, w=27, h=41, delay=4, callback=function(engine, player) player.setAnim("fall") end},
			}
		},

		flipkick={
			loop=false,
			combo = {frame=8},

			frames={
				{x=89, y=197, w=28, h=29, delay=4},
				{x=117, y=198, w=36, h=35, delay=4, callback=function(engine, player) player.playSnd("missLight") end},
				{x=201, y=197, w=39, h=39, oy=-3, delay=4,
					callback=function(engine, player)
						player.setAttackBox(true, 20, 0, 20, 39, false, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(50, -500, player, guard)
							other.giveDamage(2, 30, guard)
						end)
					end
				},
				{x=240, y=200, w=44, h=38, oy=-5, delay=4,
					callback=function(engine, player)
						player.setAttackBox(player.attackbox.on, 24, 0, 21, 38, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(50, -500, player, guard)
							other.giveDamage(2, 30, guard)
						end)
					end
				},
				{x=153, y=204, w=40, h=37, oy=-4, delay=4},
				{x=88, y=226, w=40, h=29, oy=-6, delay=4},
				{x=0, y=212, w=34, h=31, oy=-2, delay=4}
			}
		},

		tornadokick={ -- damage: 1.8, stun: 30, knockback: 50, -100, set attacker velocity to knockback if other.hitsFrom < 4
			loop=false,
			combo = {anim="tornadokick", frame=5},

			frames={
				{x=284, y=223, w=36, h=29, ox={6,6}, oy=-3, delay=4, callback=function(engine, player) player.playSnd("missLight") end},
				{x=33, y=231, w=39, h=29, ox={4,4}, oy=-3, delay=4},
				{x=236, y=238, w=48, h=29, oy=-3, delay=4,
					callback=function(engine, player)
						player.setAttackBox(true, 28, 6, 21, 23, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitWeakA")
							other.knockBack(50, -225, player, guard)
							other.giveDamage(1.8, 20, guard)
							if other.hitsFrom < 4 then
								player.vel[1] = other.vel[1]
								player.vel[2] = other.vel[2]
							end
						end)
					end
				},
				{x=128, y=233, w=37, h=33, ox={-6,-6}, delay=4},
				{x=190, y=236, w=40, h=33, ox={-4,-4}, delay=4},
				{x=190, y=236, w=40, h=33, ox={-4,-4}, delay=1, callback=function(engine, player) player.setAnim("fall") player.attacking = false end}
			}
		},

		downkick={ -- damage: 2, stun: 40, knockback: 150, 400
			loop=false,
			combo = {frame=7},

			frames={
				{x=165, y=241, w=23, h=30, oy=-5, delay=4},
				{x=284, y=252, w=37, h=41, ox={-7,-7}, oy=5, delay=4,
					callback=function(engine, player)
						player.playSnd("missLight")
						player.setAttackBox(true, 14, 17, 23, 25, false, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(150, 400, player, guard)
							other.giveDamage(2, 30, guard)
						end)
					end
				},
				{x=72, y=255, w=36, h=39, ox={-5,-5}, oy=3, delay=4,
					callback=function(engine, player)
						player.setAttackBox(player.attackbox.on, 18, 18, 18, 21, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(150, 400, player, guard)
							other.giveDamage(2, 30, guard)
						end)
					end
				},
				{x=0, y=243, w=31, h=38, ox={-3,-3}, oy=2, delay=4},
				{x=31, y=260, w=31, h=36, ox={-2,-2}, oy=-1, delay=4},
				{x=108, y=266, w=32, h=35, ox={-2,-2}, oy=-2, delay=4},
			}
		},

		spindash={
			loop=false,
			combo = {frame=24},
			img = "sonicball",

			frames={
				{x=0, y=0, w=22, h=23, delay=3,
					callback=function(engine, player)
						player.playSnd("spin")
					end
				},
				{x=22, y=0, w=22, h=22, delay=3},
				{x=44, y=0, w=20, h=21, delay=3},
				{x=64, y=0, w=24, h=23, delay=3},

				-- spindash_slide1
				{x=0, y=0, w=22, h=23, delay=3, tick=stopdashing},
				{x=22, y=0, w=22, h=22, delay=3, tick=stopdashing},
				{x=44, y=0, w=20, h=21, delay=3, tick=stopdashing},
				{x=64, y=0, w=24, h=23, delay=3, tick=stopdashing},

				{x=88, y=0, w=23, h=25, delay=3, tick=stopdashing},
				{x=0, y=23, w=20, h=23, delay=3, tick=stopdashing},
				{x=44, y=0, w=20, h=21, delay=3, tick=stopdashing},
				{x=64, y=0, w=24, h=23, delay=3, tick=stopdashing},

				-- spindash_boost level 1
				{x=88, y=0, w=23, h=25, delay=3, tick=stopdashing},
				{x=0, y=23, w=20, h=23, delay=3, tick=stopdashing},
				{x=20, y=22, w=20, h=23, delay=3, tick=stopdashing},
				{x=40, y=21, w=23, h=25, delay=3, tick=stopdashing},
				{x=88, y=0, w=23, h=25, delay=3, tick=stopdashing},

				-- spindash_boost level 2
				{x=0, y=23, w=20, h=23, delay=3, tick=stopdashing},
				{x=20, y=22, w=20, h=23, delay=3, tick=stopdashing},
				{x=40, y=21, w=23, h=25, delay=3, tick=stopdashing},
				{x=88, y=0, w=23, h=25, delay=3, tick=stopdashing},
				{x=0, y=23, w=20, h=23, delay=3, tick=stopdashing},
			}
		},

		spindash_slide1={
			loop=false,
			combo = {frame=4},

			frames={
				{x=250, y=267, w=34, h=39, delay=3,
					callback=function(engine, player)
						player.playSnd("stopspin")
					end
				},
				{x=213, y=268, w=37, h=33, delay=3},
				{x=140, y=271, w=40, h=26, delay=3,
					callback=function(engine, player)
						player.playSnd("ya")
						player.vel[1] = 450*player.dir
						player.setAnim("spindash_slide2")
					end
				}
			}
		},

		spindash_slide2={ -- damage: 1.5, stun: 45, knockback: 100, -400
			loop=false,
			combo = {frame=3},

			frames={
				{x=140, y=271, w=40, h=26, delay=20,
					callback=function(engine, player)
						player.setAttackBox(true, 22, 0, 19, 26, false, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(100, -500, player, guard, true)
							other.giveDamage(1.5, 30, guard)
						end)
					end,
				}
			}
		},

		spindash_boost={ -- damage: 2.5, stun: 45, knockback: 100, -400
			loop=false,
			combo = {frame=4},

			frames={
				{x=180, y=269, w=32, h=30, delay=6},
				{x=239, y=306, w=39, h=34, ox={37,37}, scale={3, 1}, delay=5,
					callback=function(engine, player)
						player.playSnd("zoom")
						player.vel[1] = (2500 + (1500*player.chargePower)) * player.dir
						player.setAttackBox(true, 59, 0, 58, 34, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(100, -500, player, guard, true)
							other.giveDamage(2.5, 35, guard)
						end)
					end
				},
				{x=233, y=35, w=40, h=29, delay=8,
					callback=function(engine, player)
						player.vel[1] = 300*player.dir
					end
				}
			}
		},

		flashkick={ -- damage: 2, stun: 45
			loop=false,
			combo = {frame=8},

			frames={
				{x=0, y=281, w=28, h=30, ox={-3,-3}, delay=5},
				{x=117, y=198, w=36, h=35, delay=4,
					callback=function(engine, player)
						engine.playSnd("swing")
						player.playSnd("humm")
						player.vel[2] = -500
					end
				},
				{x=201, y=197, w=39, h=39, oy=-3, delay=4,
					callback=function(engine, player)
						player.setAttackBox(true, 16, 8, 16, 26, false, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(50, -425, player, guard)
							other.giveDamage(2, 45, guard)
						end)
					end
				},
				{x=240, y=200, w=44, h=38, oy=-5, delay=4,
					callback=function(engine, player)
						player.setAttackBox(player.attackbox.on, 16, 8, 16, 26, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(50, -425, player, guard)
							other.giveDamage(2, 45, guard)
						end)
					end
				},
				{x=153, y=204, w=40, h=37, oy=-4, delay=4},
				{x=88, y=226, w=40, h=29, oy=-6, delay=4},
				{x=0, y=212, w=34, h=31, oy=-2, delay=4},
				{x=0, y=212, w=34, h=31, oy=-2, delay=1, callback=function(engine, player) player.setAnim("fall") end}
			}
		},

		bounce={ -- damage: 3, stun: 60, knockback: 100, -575
			loop=false,
			combo = {frame=4},
			img = "sonicball",

			frames={
				{x=51, y=47, w=27, h=16, delay=4},
				{x=78, y=47, w=28, h=14, delay=4},
				{x=108, y=29, w=19, h=43, delay=8,
					callback=function(engine, player)
						player.attacking = false
						player.playSnd("spring")
						player.vel[2] = -600
						player.setAttackBox(true, -1, 0, 21, 43, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(100, -575, player, guard)
							other.giveDamage(3, 40, guard)
						end)
					end
				},
				{x=108, y=29, w=19, h=43, delay=1, callback=function(engine, player) player.setAnim("jump2") end}
			}
		},

		bounceair={
			loop=true,
			combo = {frame=5},
			img = "sonicball",

			frames={
				{x=63, y=23, w=23, h=24, delay=4, callback=function(engine, player) player.attacking = false end,
					tick=function(player)
						if player.pos[2] >= 0 then player.setAnim("bounce") player.attacking = true end
					end
				},
				{x=86, y=25, w=22, h=22, oy=-1, delay=4,
					tick=function(player)
						if player.pos[2] >= 0 then player.setAnim("bounce") player.attacking = true end
					end
				},
				{x=0, y=46, w=24, h=23, ox={1,1}, oy=-1, delay=4,
					tick=function(player)
						if player.pos[2] >= 0 then player.setAnim("bounce") player.attacking = true end
					end
				},
				{x=25, y=46, w=26, h=26, ox={1,1}, oy=1, delay=4,
					tick=function(player)
						if player.pos[2] >= 0 then player.setAnim("bounce") player.attacking = true end
					end
				}
			}
		},

		soniceagle={ -- missB, damage: 2, stun: 45, knockback: 200, 450
			loop=false,
			combo = {frame=7},

			frames={
				{x=0, y=65, w=27, h=30, delay=4},
				{x=55, y=292, w=32, h=23, oy=-4, delay=4},
				{x=87, y=294, w=23, h=34, ox={-3,-3}, delay=4, callback=function(engine, player) player.playSnd("missB") end},
				{x=283, y=293, w=39, h=33, ox={-8,-8}, delay=4,
					callback=function(engine, player)
						player.setAttackBox(true, 19, 0, 17, 38, true, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							other.knockBack(200, 400, player, guard)
							other.giveDamage(2, 40, guard)
						end)
					end
				},
				{x=128, y=297, w=36, h=38, ox={-6,-6}, oy=1, delay=4},
				{x=164, y=299, w=36, h=31, ox={-7,-7}, delay=4},
				{x=200, y=301, w=34, h=31, ox={-5,-5}, oy=1, delay=4}
			}
		},

		divekick={
			loop=false,
			combo = {frame=3},

			frames={
				{x=165, y=241, w=23, h=30, oy=-5, delay=20,
					callback=function(engine, player)
						player.vel[2] = -350
					end
				},
				{x=284, y=252, w=37, h=41, ox={-7,-7}, oy=5, delay=4,
					callback=function(engine, player)
						player.playSnd("chea")
						player.setAnim("divekick2")
						player.setAttackBox(true, 14, 17, 23, 25, false, function(engine, player, other, guard)
							engine.playSnd(guard and "hitWeakB" or "hitMediumA")
							if other.pos[2] >= 0 then
								other.knockBack(150, -400, player, guard)
							else
								other.knockBack(300, 650, player, guard)
							end
							other.giveDamage(4, 45, guard)
						end)
					end
				},
			}
		},

		divekick2={ -- damage: 4, stun: 45, knockback: 350, 650
			combo = {frame=2},

			frames={
				{x=284, y=252, w=37, h=41, ox={-7,-7}, oy=5, delay=1,
					callback=function(engine, player)
						player.vel[1] = 500*player.dir
						player.vel[2] = 650
						if player.pos[2] >= 0 then
							player.attacking = false
							player.attackbox.on = false
						end
					end
				},
			}
		}
	}
}


local TACTIC_JABS = 0
local TACTIC_JABSWEEP = 1
local TACTIC_UPKICK = 2
local TACTIC_BOUNCE = 3
local TACTIC_SPINDASH = 4
local TACTIC_FLASHKICK = 5
local TACTIC_DIVEKICK = 6
local MAX_TACTICS = 7

local cpuEnemy, cpuGuard, cpuTactic, cpuTacticState, cpuTacticSwitch, cpuAttackTick, cpuReleaseAttack

function fighter.cpu(engine, player)
	if not cpuEnemy then
		cpuGuard = 0
		cpuTactic = rand(MAX_TACTICS)
		cpuTacticState = 0
		cpuTacticSwitch = 120 + rand(60)
		cpuAttackTick = 8
		for i=1, #engine.players do
			if engine.players[i] ~= player then
				cpuEnemy = engine.players[i]
				break
			end
		end
	end

	local inputs = player.inputs
	local frame = player.anims[player.anim.name]

	--local dist = math.sqrt(math.pow(cpuEnemy.pos[2] - player.pos[2], 2) + math.pow(cpuEnemy.pos[1] - player.pos[1], 2))
	local xdiff = cpuEnemy.pos[1] - player.pos[1]
	local xdist = math.abs(xdiff)
	local xdir = xdiff >= 0 and 1 or -1
	local ydiff = cpuEnemy.pos[2] - player.pos[2]
	local ydist = math.abs(ydiff)
	local ydir = (cpuEnemy.pos[2] > player.pos[2] and 1) or (cpuEnemy.pos[2] < player.pos[2] and -1) or 0

	local avoidPlayer = cpuEnemy.attacking and cpuEnemy.anims[cpuEnemy.anim.name].breakthrough and xdist < 56
	if avoidPlayer and cpuGuard > 10 then
		cpuGuard = rand(10)
	end

	if player.stun > 0 then
		cpuGuard = 15 + rand(60)
		inputs.attack = false

	elseif player.guardStun > 0 then
		cpuGuard = 10 + rand(20)
		inputs.attack = false

	elseif cpuGuard > 0 then
		cpuGuard = cpuGuard-1
		inputs.attack = false

	else
		inputs.dir.x = (avoidPlayer and -xdir) or ((xdist > 16 or player.dir ~= xdir) and xdir) or 0
	end

	cpuTacticSwitch = cpuTacticSwitch-1
	if cpuTacticSwitch <= 0 then
		cpuTactic = rand(MAX_TACTICS)
		cpuTacticState = 0
		cpuTacticSwitch = 60 + rand(30)
	end

	local anim = player.anims[player.anim.name]
	inputs.jump = false
	if cpuTactic == TACTIC_JABS and xdist <= 40 and ydist < 32 then
		inputs.attack = true
		inputs.dir.y = 0
		inputs.trigger = false
		inputs.jump = rand(53) >= 46
		cpuTacticSwitch = cpuTacticSwitch-1

	elseif cpuTactic == TACTIC_JABSWEEP and xdist <= 40 and ydist < 32 then
		inputs.attack = true
		inputs.trigger = false
		inputs.dir.y = (player.anim.name == "jabcombo2" and player.anim.frame >= anim.combo.frame) and 1 or 0
		local nextt = player.anim.name == "sweepkick" and rand(50) or 0
		if nextt >= 40 then
			cpuTactic = TACTIC_SPINDASH
			cpuTacticSwitch = 90
		elseif nextt >= 15 then
			inputs.jump = true
		end

	elseif cpuTactic == TACTIC_UPKICK or (xdist < 32 and ydist < 32) then
		inputs.dir.y = -1
		inputs.trigger = false
		inputs.attack = true
		if rand(50) >= 40 then
			cpuTactic = rand(MAX_TACTICS)
			cpuTacticSwitch = 90
		end

	elseif cpuTactic == TACTIC_BOUNCE and xdist <= 40 and ydist < 56 then
		inputs.dir.y = -1
		inputs.trigger = true
		inputs.attack = true

	elseif cpuTactic == TACTIC_SPINDASH and xdist < 64 and ydist < 48 then
		inputs.dir.y = 0
		inputs.trigger = true
		inputs.attack = true
		inputs.attackHold = true
		cpuTacticSwitch = cpuTacticSwitch+1 -- don't run out
		if not cpuReleaseAttack then cpuReleaseAttack = rand(67)
		else
			cpuReleaseAttack = cpuReleaseAttack-1
			if cpuReleaseAttack <= 0 then
				inputs.attack = false
				inputs.attackHold = false
				cpuReleaseAttack = false
				cpuTactic = rand(MAX_TACTICS)
				cpuTacticSwitch = 90
			end
		end

	elseif cpuTactic == TACTIC_FLASHKICK and xdist < 48 then
		inputs.dir.y = 1
		inputs.trigger = true
		inputs.attack = true
		cpuTactic = TACTIC_JABS
		cpuTacticSwitch = 100

	elseif cpuTactic == TACTIC_DIVEKICK and xdist < 128 then
		inputs.jump = true
		inputs.trigger = false
		inputs.attack = false
		if ydir > 0 and xdist < 100 then -- we're above
			inputs.dir.y = 1
			inputs.trigger = true
			inputs.attack = true
			if rand(30) >= 20 then
				cpuTactic = rand(MAX_TACTICS)
				cpuTacticSwitch = 90
			end
		end

	else
		inputs.attack = false
		inputs.trigger = false
	end

	if inputs.attack then
		if cpuAttackTick <= 0 then cpuAttackTick = 8
		else
			cpuAttackTick = cpuAttackTick-1
			inputs.attack = false
		end
	else
		cpuAttackTick = 8
	end

	inputs.guard = cpuGuard > 0
end

return fighter
